#include "settings.h"

Settings settings;
